//
//  DYYYOSCompat.m
//  兼容缺失 libclang_rt 的 Linux 工具链：提供 clang 运行时符号 __isOSVersionAtLeast
//
#import <Foundation/Foundation.h>

bool __isOSVersionAtLeast(int Major, int Minor, int Subminor) {
    if (@available(iOS 8.0, *)) {
        NSOperatingSystemVersion version = [[NSProcessInfo processInfo] operatingSystemVersion];
        if (version.majorVersion != Major) {
            return version.majorVersion > Major;
        }
        if (version.minorVersion != Minor) {
            return version.minorVersion > Minor;
        }
        return version.patchVersion >= Subminor;
    }
    return true;
}
